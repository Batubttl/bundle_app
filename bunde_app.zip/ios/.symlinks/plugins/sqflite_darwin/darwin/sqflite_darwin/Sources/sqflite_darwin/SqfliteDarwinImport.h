//
//  SqfliteDarwinImport.h
//  Shared import for SqfliteDarwinDB
//
// Not a header file as XCode might complain.
//
//  Created by Alexandre Roux on 03/12/2022.
//
#ifndef SqfliteDarwinImport_h
#define SqfliteDarwinImport_h

#import "SqfliteDarwinDB.h"

#endif /* SqfliteDarwinImport_h */
